# Default variables used for the ntlm_context
username = 'username'
domain = 'domain'
password = 'password'

# Genearated online as hashlib.md4 may not be available anymore
password_md4 = '8a9d093f14f8701df17732b2bb182c74'